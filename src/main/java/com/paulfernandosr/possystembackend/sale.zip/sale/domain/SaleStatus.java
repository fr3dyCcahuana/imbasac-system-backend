package com.paulfernandosr.possystembackend.sale.domain;

public enum SaleStatus {
    PAID,
    CANCELLED
}
