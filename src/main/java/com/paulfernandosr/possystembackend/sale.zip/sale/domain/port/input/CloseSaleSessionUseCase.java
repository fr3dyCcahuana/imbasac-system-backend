package com.paulfernandosr.possystembackend.sale.domain.port.input;

public interface CloseSaleSessionUseCase {
    void closeSaleSessionById(Long saleSessionId);
}
