package com.paulfernandosr.possystembackend.product.domain.exception;

public class InvalidProductSerialUnitException extends RuntimeException {
    public InvalidProductSerialUnitException(String message) {
        super(message);
    }
}
