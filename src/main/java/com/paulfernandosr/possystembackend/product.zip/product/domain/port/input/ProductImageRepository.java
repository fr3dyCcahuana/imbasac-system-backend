package com.paulfernandosr.possystembackend.product.domain.port.input;

public class ProductImageRepository {
}
