package com.paulfernandosr.possystembackend.product.domain.exception;

public class ProductVehicleDetailNotFoundException extends RuntimeException {
    public ProductVehicleDetailNotFoundException(String message) {
        super(message);
    }
}
