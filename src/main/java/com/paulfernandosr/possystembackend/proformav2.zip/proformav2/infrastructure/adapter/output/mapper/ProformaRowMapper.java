package com.paulfernandosr.possystembackend.proformav2.infrastructure.adapter.output.mapper;

import com.paulfernandosr.possystembackend.proformav2.domain.Proforma;
import com.paulfernandosr.possystembackend.proformav2.domain.model.ProformaStatus;
import com.paulfernandosr.possystembackend.salev2.domain.model.PaymentType;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

public class ProformaRowMapper implements RowMapper<Proforma> {

    @Override
    public Proforma mapRow(ResultSet rs, int rowNum) throws SQLException {
        Proforma.ProformaBuilder builder = Proforma.builder()
                .id(rs.getLong("id"))
                .stationId(rs.getLong("station_id"))
                .createdBy(rs.getLong("created_by"))
                .series(rs.getString("series"))
                .number(rs.getLong("number"))
                .issueDate(rs.getDate("issue_date").toLocalDate())
                .priceList(rs.getString("price_list").charAt(0))
                .currency(rs.getString("currency"))
                .customerId((Long) rs.getObject("customer_id"))
                .customerDocType(rs.getString("customer_doc_type"))
                .customerDocNumber(rs.getString("customer_doc_number"))
                .customerName(rs.getString("customer_name"))
                .customerAddress(rs.getString("customer_address"))
                .notes(rs.getString("notes"))
                .subtotal(rs.getBigDecimal("subtotal"))
                .discountTotal(rs.getBigDecimal("discount_total"))
                .total(rs.getBigDecimal("total"))
                .status(ProformaStatus.valueOf(rs.getString("status")))
                .createdAt(rs.getTimestamp("created_at").toLocalDateTime())
                .updatedAt(rs.getTimestamp("updated_at").toLocalDateTime());

        // ✅ columnas opcionales (cuando viene con JOIN users)
        Set<String> cols = columns(rs);
        if (cols.contains("cashier_username")) {
            builder.cashierUsername(rs.getString("cashier_username"));
        }
        if (cols.contains("cashier_first_name")) {
            builder.cashierFirstName(rs.getString("cashier_first_name"));
        }
        if (cols.contains("cashier_last_name")) {
            builder.cashierLastName(rs.getString("cashier_last_name"));
        }

        builder.customerUbigeo(readString(rs, cols, "customer_ubigeo_resolved", "customer_ubigeo"));
        builder.customerDepartment(readString(rs, cols, "customer_department_resolved", "customer_department"));
        builder.customerProvince(readString(rs, cols, "customer_province_resolved", "customer_province"));
        builder.customerDistrict(readString(rs, cols, "customer_district_resolved", "customer_district"));

        if (cols.contains("payment_type")) {
            String paymentType = rs.getString("payment_type");
            if (paymentType != null && !paymentType.isBlank()) {
                builder.paymentType(PaymentType.valueOf(paymentType));
            }
        }
        if (cols.contains("credit_days")) {
            builder.creditDays((Integer) rs.getObject("credit_days"));
        }
        if (cols.contains("due_date")) {
            java.sql.Date dueDate = rs.getDate("due_date");
            if (dueDate != null) {
                builder.dueDate(dueDate.toLocalDate());
            }
        }

        if (cols.contains("tax_status")) {
            builder.taxStatus(rs.getString("tax_status"));
        }
        if (cols.contains("igv_rate")) {
            builder.igvRate(rs.getBigDecimal("igv_rate"));
        }
        if (cols.contains("igv_amount")) {
            builder.igvAmount(rs.getBigDecimal("igv_amount"));
        }
        if (cols.contains("igv_included")) {
            builder.igvIncluded((Boolean) rs.getObject("igv_included"));
        }

        if (cols.contains("converted_sale_id")) {
            builder.convertedSaleId((Long) rs.getObject("converted_sale_id"));
        }
        if (cols.contains("converted_at")) {
            java.sql.Timestamp convertedAt = rs.getTimestamp("converted_at");
            if (convertedAt != null) {
                builder.convertedAt(convertedAt.toLocalDateTime());
            }
        }
        if (cols.contains("converted_by")) {
            builder.convertedBy((Long) rs.getObject("converted_by"));
        }
        return builder.build();
    }

    private static String readString(ResultSet rs, Set<String> cols, String preferredColumn, String fallbackColumn) throws SQLException {
        if (cols.contains(preferredColumn)) {
            return rs.getString(preferredColumn);
        }
        if (cols.contains(fallbackColumn)) {
            return rs.getString(fallbackColumn);
        }
        return null;
    }

    private static Set<String> columns(ResultSet rs) throws SQLException {
        ResultSetMetaData md = rs.getMetaData();
        Set<String> set = new HashSet<>();
        for (int i = 1; i <= md.getColumnCount(); i++) {
            set.add(md.getColumnLabel(i)); // usa alias (AS ...)
        }
        return set;
    }
}
