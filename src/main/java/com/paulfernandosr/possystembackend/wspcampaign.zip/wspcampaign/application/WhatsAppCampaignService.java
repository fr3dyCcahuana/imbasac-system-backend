package com.paulfernandosr.possystembackend.wspcampaign.application;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paulfernandosr.possystembackend.wspcampaign.domain.*;
import com.paulfernandosr.possystembackend.wspcampaign.domain.port.output.WhatsAppCampaignNotificationGateway;
import com.paulfernandosr.possystembackend.wspcampaign.domain.port.output.WhatsAppCampaignRepository;
import com.paulfernandosr.possystembackend.wspcampaign.domain.port.output.WhatsAppCampaignTraceGateway;
import com.paulfernandosr.possystembackend.wspcampaign.infrastructure.adapter.input.dto.WhatsAppCampaignCreateRequest;
import com.paulfernandosr.possystembackend.wspcampaign.infrastructure.adapter.input.dto.WhatsAppCampaignPreviewRequest;
import com.paulfernandosr.possystembackend.wspcampaign.infrastructure.adapter.input.dto.WhatsAppCampaignTargetRequest;
import com.paulfernandosr.possystembackend.whatsapp.application.WhatsAppIntegrationProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static org.springframework.http.HttpStatus.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class WhatsAppCampaignService {
    private final WhatsAppCampaignRepository campaignRepository;
    private final WhatsAppCampaignNotificationGateway notificationGateway;
    private final WhatsAppCampaignTraceGateway traceGateway;
    private final WhatsAppIntegrationProperties properties;
    private final ObjectMapper objectMapper;

    /** Worker dedicado para campañas. No procesa conversaciones ni automatizaciones del chat. */
    private final ExecutorService executor = Executors.newSingleThreadExecutor(runnable -> {
        Thread thread = new Thread(runnable);
        thread.setName("whatsapp-campaign-worker");
        thread.setDaemon(true);
        return thread;
    });

    public WhatsAppCampaignPreview preview(WhatsAppCampaignPreviewRequest request) {
        var target = normalizeTarget(request == null ? null : request.getTarget());
        validateTargetForMode(target);
        int limit = safeLimit(target.getLimit());
        boolean filteredOptIn = shouldFilterOptIn(target);
        List<WhatsAppCampaignRecipient> selected = campaignRepository.previewRecipients(
                target.getMode(),
                filteredOptIn,
                target.getContactIds(),
                target.getWaIds(),
                limit
        );
        return WhatsAppCampaignPreview.builder()
                .totalContacts(selected.size())
                .selectedRecipients(selected.size())
                .limitedTo(limit)
                .optedInRecipients(filteredOptIn ? selected.size() : 0)
                .notOptedInRecipients(filteredOptIn ? 0 : selected.size())
                .sample(selected.stream().limit(10).toList())
                .build();
    }

    @Transactional
    public WhatsAppCampaign createCampaign(WhatsAppCampaignCreateRequest request) {
        assertCampaignEnabled();
        validateCreateRequest(request);
        var target = normalizeTarget(request.getTarget());
        validateTargetForMode(target);
        int limit = safeLimit(target.getLimit());
        boolean onlyOptedIn = shouldFilterOptIn(target);
        List<WhatsAppCampaignRecipient> recipients = campaignRepository.previewRecipients(
                target.getMode(),
                onlyOptedIn,
                target.getContactIds(),
                target.getWaIds(),
                limit
        );
        if (recipients.isEmpty()) {
            throw new ResponseStatusException(BAD_REQUEST, "No hay destinatarios para la campaña.");
        }

        String bodyParametersJson = toJson(normalizeBodyParameters(request.getBodyParameters()));
        WhatsAppCampaign campaign = WhatsAppCampaign.builder()
                .name(request.getName().trim())
                .description(trimToNull(request.getDescription()))
                .status(WhatsAppCampaignStatus.DRAFT)
                .recipientMode(target.getMode())
                .onlyOptedIn(onlyOptedIn)
                .templateName(request.getTemplateName().trim())
                .languageCode(normalizeLanguage(request.getLanguageCode()))
                .imageUrl(trimToNull(request.getImageUrl()))
                .bodyParametersJson(bodyParametersJson)
                .totalRecipients(recipients.size())
                .createdBy(trimToNull(request.getCreatedBy()) == null ? "SYSTEM" : request.getCreatedBy().trim())
                .build();
        WhatsAppCampaign saved = campaignRepository.saveCampaign(campaign);
        campaignRepository.replaceRecipients(saved.getId(), recipients);
        return campaignRepository.findCampaignById(saved.getId()).orElse(saved);
    }

    public WhatsAppCampaign startCampaign(Long campaignId) {
        assertCampaignEnabled();
        WhatsAppCampaign campaign = campaignRepository.findCampaignById(campaignId)
                .orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "Campaña WhatsApp no encontrada."));
        if (campaign.getStatus() != WhatsAppCampaignStatus.DRAFT && campaign.getStatus() != WhatsAppCampaignStatus.QUEUED) {
            throw new ResponseStatusException(CONFLICT, "La campaña no está en estado DRAFT/QUEUED.");
        }
        campaignRepository.updateStatus(campaignId, WhatsAppCampaignStatus.QUEUED, null);
        executor.submit(() -> runCampaign(campaignId));
        return campaignRepository.findCampaignById(campaignId).orElse(campaign);
    }

    public List<WhatsAppCampaign> listCampaigns(int page, int size) {
        return campaignRepository.listCampaigns(Math.max(page, 0), normalizeSize(size));
    }

    public WhatsAppCampaign getCampaign(Long id) {
        return campaignRepository.findCampaignById(id)
                .orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "Campaña WhatsApp no encontrada."));
    }

    public List<WhatsAppCampaignRecipient> getRecipients(Long campaignId, int page, int size) {
        getCampaign(campaignId);
        return campaignRepository.findRecipients(campaignId, Math.max(page, 0), normalizeSize(size));
    }

    public WhatsAppCampaignRecipientSupport getRecipientSupport(Long campaignId, Long recipientId) {
        getCampaign(campaignId);
        return campaignRepository.findRecipientSupport(campaignId, recipientId)
                .orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "Destinatario de campaña no encontrado."));
    }

    private void runCampaign(Long campaignId) {
        int sent = 0;
        int failed = 0;
        int skipped = 0;
        String finalError = null;
        try {
            WhatsAppCampaign campaign = campaignRepository.findCampaignById(campaignId)
                    .orElseThrow(() -> new IllegalStateException("Campaña no encontrada: " + campaignId));
            campaignRepository.markStarted(campaignId);
            List<WhatsAppCampaignRecipient> recipients = campaignRepository.findPendingRecipients(campaignId);
            List<String> bodyParameters = parseBodyParameters(campaign.getBodyParametersJson());

            for (WhatsAppCampaignRecipient recipient : recipients) {
                try {
                    if (recipient.getWaId() == null || recipient.getWaId().isBlank()) {
                        campaignRepository.markRecipientSkipped(recipient.getId(), "Contacto sin wa_id.");
                        skipped++;
                        continue;
                    }
                    log.info("Enviando campaña WhatsApp. campaignId={}, recipientId={}, waId={}, template={}, imageUrl={}",
                            campaignId, recipient.getId(), recipient.getWaId(), campaign.getTemplateName(), campaign.getImageUrl());
                    WhatsAppCampaignNotificationResult result = notificationGateway.sendTemplateNotification(
                            recipient.getWaId(),
                            campaign.getTemplateName(),
                            campaign.getLanguageCode(),
                            campaign.getImageUrl(),
                            bodyParameters
                    );
                    log.info("Respuesta Meta campaña WhatsApp. campaignId={}, recipientId={}, waId={}, waMessageId={}, status={}",
                            campaignId, recipient.getId(), recipient.getWaId(), result.getWaMessageId(), result.getStatus());
                    try {
                        traceGateway.recordOutboundTemplate(campaign, recipient, result, bodyParameters);
                    } catch (Exception traceEx) {
                        log.warn("No se pudo registrar trazabilidad WhatsApp. campaignId={}, recipientId={}, waId={}, error={}",
                                campaignId, recipient.getId(), recipient.getWaId(), traceEx.getMessage());
                    }
                    campaignRepository.markRecipientSent(recipient.getId(), result.getWaMessageId());
                    sent++;
                    pauseBetweenMessages();
                } catch (Exception ex) {
                    log.warn("No se pudo enviar campaña WhatsApp. campaignId={}, recipientId={}, waId={}, error={}",
                            campaignId, recipient.getId(), recipient.getWaId(), ex.getMessage());
                    campaignRepository.markRecipientFailed(recipient.getId(), ex.getMessage());
                    failed++;
                }
            }
        } catch (Exception ex) {
            failed++;
            finalError = ex.getMessage();
            log.error("Campaña WhatsApp fallida. campaignId={}", campaignId, ex);
        } finally {
            WhatsAppCampaignStatus status = resolveFinalStatus(sent, failed, skipped);
            campaignRepository.markCompleted(campaignId, status, sent, failed, skipped, finalError);
        }
    }

    private WhatsAppCampaignStatus resolveFinalStatus(int sent, int failed, int skipped) {
        if (sent > 0 && failed == 0 && skipped == 0) return WhatsAppCampaignStatus.COMPLETED;
        if (sent > 0) return WhatsAppCampaignStatus.COMPLETED_WITH_ERRORS;
        if (skipped > 0 && failed == 0) return WhatsAppCampaignStatus.COMPLETED_WITH_ERRORS;
        return WhatsAppCampaignStatus.FAILED;
    }

    private void pauseBetweenMessages() {
        long delay = Math.max(0, properties.getCampaign().getDelayMillisBetweenMessages());
        if (delay <= 0) return;
        try {
            Thread.sleep(delay);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
    }

    private void assertCampaignEnabled() {
        if (!properties.getCampaign().isEnabled()) {
            throw new ResponseStatusException(FORBIDDEN, "Campañas WhatsApp deshabilitadas por configuración.");
        }
    }

    private void validateCreateRequest(WhatsAppCampaignCreateRequest request) {
        if (request == null) throw new ResponseStatusException(BAD_REQUEST, "Solicitud vacía.");
        if (isBlank(request.getName())) throw new ResponseStatusException(BAD_REQUEST, "El nombre de campaña es obligatorio.");
        if (isBlank(request.getTemplateName())) throw new ResponseStatusException(BAD_REQUEST, "La plantilla aprobada de Meta es obligatoria.");
        if (!isBlank(request.getImageUrl()) && !request.getImageUrl().trim().startsWith("https://")) {
            throw new ResponseStatusException(BAD_REQUEST, "La imagen de campaña debe ser una URL HTTPS pública.");
        }
        if (properties.getCampaign().isRequirePolicyConfirmation() && !Boolean.TRUE.equals(request.getConfirmPolicyCompliance())) {
            throw new ResponseStatusException(BAD_REQUEST, "Debes confirmar que los destinatarios aceptaron recibir promociones y que usarás una plantilla aprobada.");
        }
    }

    private WhatsAppCampaignTargetRequest normalizeTarget(WhatsAppCampaignTargetRequest target) {
        WhatsAppCampaignTargetRequest normalized = target == null ? new WhatsAppCampaignTargetRequest() : target;
        if (normalized.getMode() == null) normalized.setMode(WhatsAppCampaignRecipientMode.ONLY_OPTED_IN);
        if (normalized.getWaIds() != null) {
            normalized.setWaIds(normalized.getWaIds().stream()
                    .filter(Objects::nonNull)
                    .map(this::normalizeWaId)
                    .filter(value -> !value.isBlank())
                    .distinct()
                    .toList());
        }
        return normalized;
    }

    private boolean shouldFilterOptIn(WhatsAppCampaignTargetRequest target) {
        if (target.getMode() == WhatsAppCampaignRecipientMode.WA_IDS) {
            // En modo WA_IDS el usuario define números puntuales. La confirmación de política queda en la campaña.
            // Esto evita que una prueba controlada termine seleccionando contactos distintos o vacíos por filtros de opt-in.
            return false;
        }
        if (target.getOnlyOptedIn() != null) return target.getOnlyOptedIn();
        return properties.getCampaign().isOnlyOptedInByDefault() || target.getMode() == WhatsAppCampaignRecipientMode.ONLY_OPTED_IN;
    }

    private void validateTargetForMode(WhatsAppCampaignTargetRequest target) {
        if (target.getMode() == WhatsAppCampaignRecipientMode.WA_IDS && (target.getWaIds() == null || target.getWaIds().isEmpty())) {
            throw new ResponseStatusException(BAD_REQUEST, "Debes enviar al menos un waId cuando el modo es WA_IDS.");
        }
        if (target.getMode() == WhatsAppCampaignRecipientMode.CONTACT_IDS && (target.getContactIds() == null || target.getContactIds().isEmpty())) {
            throw new ResponseStatusException(BAD_REQUEST, "Debes enviar al menos un contactId cuando el modo es CONTACT_IDS.");
        }
    }

    private int safeLimit(Integer requested) {
        int max = Math.max(1, properties.getCampaign().getMaxRecipientsPerCampaign());
        if (requested == null || requested <= 0) return max;
        return Math.min(requested, max);
    }

    private int normalizeSize(int size) {
        if (size <= 0) return 20;
        return Math.min(size, 100);
    }

    private String normalizeLanguage(String value) {
        return isBlank(value) ? "es" : value.trim();
    }

    private String normalizeWaId(String value) {
        return value == null ? "" : value.replace("+", "").replace(" ", "").replace("-", "").trim();
    }

    private List<String> normalizeBodyParameters(List<String> values) {
        if (values == null || values.isEmpty()) return List.of();
        return values.stream()
                .map(value -> value == null ? "" : value)
                .toList();
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }

    private String trimToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String toJson(List<String> values) {
        try {
            return objectMapper.writeValueAsString(values == null ? List.of() : values);
        } catch (Exception ex) {
            throw new ResponseStatusException(BAD_REQUEST, "No se pudieron serializar parámetros de plantilla.", ex);
        }
    }

    private List<String> parseBodyParameters(String json) {
        try {
            if (json == null || json.isBlank()) return List.of();
            return objectMapper.readValue(json, new TypeReference<List<String>>() {});
        } catch (Exception ex) {
            return List.of();
        }
    }
}
