package com.paulfernandosr.possystembackend.wspcampaign.domain.port.output;

import com.paulfernandosr.possystembackend.wspcampaign.domain.WhatsAppCampaign;
import com.paulfernandosr.possystembackend.wspcampaign.domain.WhatsAppCampaignRecipient;
import com.paulfernandosr.possystembackend.wspcampaign.domain.WhatsAppCampaignRecipientMode;
import com.paulfernandosr.possystembackend.wspcampaign.domain.WhatsAppCampaignRecipientSupport;
import com.paulfernandosr.possystembackend.wspcampaign.domain.WhatsAppCampaignStatus;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface WhatsAppCampaignRepository {
    WhatsAppCampaign saveCampaign(WhatsAppCampaign campaign);
    Optional<WhatsAppCampaign> findCampaignById(Long id);
    List<WhatsAppCampaign> listCampaigns(int page, int size);
    long countCampaigns();
    void updateStatus(Long campaignId, WhatsAppCampaignStatus status, String errorMessage);
    void markStarted(Long campaignId);
    void markCompleted(Long campaignId, WhatsAppCampaignStatus status, int sent, int failed, int skipped, String errorMessage);

    List<WhatsAppCampaignRecipient> previewRecipients(WhatsAppCampaignRecipientMode mode,
                                                      boolean onlyOptedIn,
                                                      Collection<Long> contactIds,
                                                      Collection<String> waIds,
                                                      int limit);

    void replaceRecipients(Long campaignId, List<WhatsAppCampaignRecipient> recipients);
    List<WhatsAppCampaignRecipient> findPendingRecipients(Long campaignId);
    List<WhatsAppCampaignRecipient> findRecipients(Long campaignId, int page, int size);
    Optional<WhatsAppCampaignRecipientSupport> findRecipientSupport(Long campaignId, Long recipientId);
    void markRecipientSent(Long recipientId, String waMessageId);
    void markRecipientFailed(Long recipientId, String errorMessage);
    void markRecipientSkipped(Long recipientId, String reason);
}
