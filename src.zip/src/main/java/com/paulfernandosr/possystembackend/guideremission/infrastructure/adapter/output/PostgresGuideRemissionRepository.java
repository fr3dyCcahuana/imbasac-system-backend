package com.paulfernandosr.possystembackend.guideremission.infrastructure.adapter.output;

import com.paulfernandosr.possystembackend.guideremission.domain.*;
import com.paulfernandosr.possystembackend.guideremission.domain.exception.InvalidGuideRemissionException;
import com.paulfernandosr.possystembackend.guideremission.domain.port.output.GuideRemissionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class PostgresGuideRemissionRepository implements GuideRemissionRepository {

    private static final ZoneId GRE_DEFAULT_ZONE = ZoneId.of("America/Lima");
    private final JdbcClient jdbcClient;

    @Override
    public void saveSubmission(GuideRemissionCompany company, GuideRemissionSubmission request, GuideRemissionSubmissionResponse response) {
        Long existingId = findId(company.getRuc(), request.getGuia().getSerie(), request.getGuia().getNumero()).orElse(null);

        if (existingId == null) {
            existingId = insertHeader(company, request, response);
        } else {
            updateHeader(existingId, company, request, response);
            deleteItemAllocations(existingId);
            deleteItems(existingId);
            deleteRelatedDocuments(existingId);
        }

        insertRelatedDocuments(existingId, request.getRelatedDocuments());
        insertItems(existingId, request.getItems());
    }

    @Override
    public void saveTicketStatus(String companyRuc, GuideRemissionTicketQuery request, GuideRemissionTicketStatusResponse response) {
        Long existingId = findId(companyRuc, request.getSerie(), request.getNumero()).orElse(null);
        GuideRemissionStatus status = resolveStatus(response);

        if (existingId == null) {
            String insertSql = """
                    INSERT INTO guide_remissions(
                        company_ruc,
                        serie,
                        numero,
                        ticket,
                        status,
                        ticket_response_code,
                        cdr_generated,
                        cdr_hash,
                        cdr_message,
                        document_description,
                        ruta_xml,
                        ruta_cdr,
                        error_code,
                        ticket_checked_at,
                        created_at,
                        updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
                    """;

            jdbcClient.sql(insertSql)
                    .params(
                            companyRuc,
                            request.getSerie(),
                            request.getNumero(),
                            request.getTicket(),
                            status.name(),
                            firstNonBlank(response.getCdrResponseCode(), response.getTicketRpta()),
                            response.getIndCdrGenerado(),
                            response.getCdrHash(),
                            response.getCdrMsjSunat(),
                            response.getDocumentDescription(),
                            response.getRutaXml(),
                            response.getRutaCdr(),
                            response.getNumerror(),
                            OffsetDateTime.now()
                    )
                    .update();
            return;
        }

        String updateSql = """
                UPDATE guide_remissions
                   SET ticket = ?,
                       status = ?,
                       ticket_response_code = ?,
                       cdr_generated = ?,
                       cdr_hash = ?,
                       cdr_message = ?,
                       document_description = ?,
                       ruta_xml = ?,
                       ruta_cdr = ?,
                       error_code = ?,
                       ticket_checked_at = ?,
                       updated_at = NOW()
                 WHERE id = ?
                """;

        jdbcClient.sql(updateSql)
                .params(
                        request.getTicket(),
                        status.name(),
                        firstNonBlank(response.getCdrResponseCode(), response.getTicketRpta()),
                        response.getIndCdrGenerado(),
                        response.getCdrHash(),
                        response.getCdrMsjSunat(),
                        response.getDocumentDescription(),
                        response.getRutaXml(),
                        response.getRutaCdr(),
                        response.getNumerror(),
                        OffsetDateTime.now(),
                        existingId
                )
                .update();
    }

    @Override
    public Optional<GuideRemissionDocument> findDocument(String companyRuc, String serie, String numero) {
        List<GuideRemissionDocument> documents = jdbcClient.sql("""
                SELECT id,
                       company_ruc,
                       serie,
                       numero,
                       issue_date,
                       issue_time,
                       transfer_date,
                       transfer_reason_code,
                       transfer_mode_code,
                       related_document_type_code,
                       related_document_serie,
                       related_document_numero,
                       transporter_document_number,
                       transporter_name,
                       legacy_transport_entity_id,
                       legacy_transport_mtc_number,
                       driver_dni,
                       driver_full_name,
                       driver_license,
                       vehicle_plate,
                       recipient_document_type,
                       recipient_document_number,
                       recipient_name,
                       departure_ubigeo,
                       departure_address,
                       departure_establishment_code,
                       arrival_ubigeo,
                       arrival_address,
                       arrival_establishment_code,
                       total_weight,
                       number_of_packages,
                       notes,
                       ticket,
                       status,
                       ticket_response_code,
                       cdr_generated,
                       cdr_hash,
                       cdr_message,
                       document_description,
                       submitted_at
                  FROM guide_remissions
                 WHERE company_ruc = ?
                   AND serie = ?
                   AND numero = ?
                """)
                .params(companyRuc, serie, numero)
                .query((rs, rowNum) -> GuideRemissionDocument.builder()
                        .id(rs.getLong("id"))
                        .companyRuc(rs.getString("company_ruc"))
                        .serie(rs.getString("serie"))
                        .numero(rs.getString("numero"))
                        .issueDate(rs.getObject("issue_date", LocalDate.class))
                        .issueTime(rs.getObject("issue_time", LocalTime.class))
                        .transferDate(rs.getObject("transfer_date", LocalDate.class))
                        .transferReasonCode(rs.getString("transfer_reason_code"))
                        .transferModeCode(rs.getString("transfer_mode_code"))
                        .relatedDocumentTypeCode(rs.getString("related_document_type_code"))
                        .relatedDocumentSerie(rs.getString("related_document_serie"))
                        .relatedDocumentNumero(rs.getString("related_document_numero"))
                        .transporterDocumentNumber(rs.getString("transporter_document_number"))
                        .transporterName(rs.getString("transporter_name"))
                        .legacyTransportEntityId(rs.getString("legacy_transport_entity_id"))
                        .legacyTransportMtcNumber(rs.getString("legacy_transport_mtc_number"))
                        .driverDni(rs.getString("driver_dni"))
                        .driverFullName(rs.getString("driver_full_name"))
                        .driverLicense(rs.getString("driver_license"))
                        .vehiclePlate(rs.getString("vehicle_plate"))
                        .recipientDocumentType(rs.getObject("recipient_document_type", Integer.class))
                        .recipientDocumentNumber(rs.getString("recipient_document_number"))
                        .recipientName(rs.getString("recipient_name"))
                        .departureUbigeo(rs.getString("departure_ubigeo"))
                        .departureAddress(rs.getString("departure_address"))
                        .departureEstablishmentCode(rs.getString("departure_establishment_code"))
                        .arrivalUbigeo(rs.getString("arrival_ubigeo"))
                        .arrivalAddress(rs.getString("arrival_address"))
                        .arrivalEstablishmentCode(rs.getString("arrival_establishment_code"))
                        .totalWeight(rs.getBigDecimal("total_weight"))
                        .numberOfPackages(rs.getString("number_of_packages"))
                        .notes(rs.getString("notes"))
                        .ticket(rs.getString("ticket"))
                        .status(rs.getString("status"))
                        .ticketResponseCode(rs.getString("ticket_response_code"))
                        .cdrGenerated(rs.getString("cdr_generated"))
                        .cdrHash(rs.getString("cdr_hash"))
                        .cdrMessage(rs.getString("cdr_message"))
                        .documentDescription(rs.getString("document_description"))
                        .submittedAt(rs.getObject("submitted_at", OffsetDateTime.class))
                        .relatedDocuments(new ArrayList<>())
                        .items(new ArrayList<>())
                        .build())
                .list();

        if (documents.isEmpty()) {
            return Optional.empty();
        }

        GuideRemissionDocument document = documents.get(0);
        enrichLocationNames(document);
        document.setRelatedDocuments(loadRelatedDocuments(document));
        document.setItems(loadItems(document.getId()));
        return Optional.of(document);
    }

    @Override
    public GuideRemissionGeneratedSeries reserveNextGuideRemissionSeries() {
        List<DocumentSeriesRow> rows = jdbcClient.sql("""
                SELECT id, series, next_number
                  FROM document_series
                 WHERE UPPER(doc_type) = ?
                   AND enabled = TRUE
                 FOR UPDATE
                """)
                .param("GUIDE_REMISSION")
                .query((rs, rowNum) -> new DocumentSeriesRow(
                        rs.getLong("id"),
                        rs.getString("series"),
                        rs.getLong("next_number")
                ))
                .list();

        if (rows.isEmpty()) {
            throw new InvalidGuideRemissionException(
                    "No existe una serie activa en document_series para el doc_type GUIDE_REMISSION."
            );
        }
        if (rows.size() > 1) {
            throw new InvalidGuideRemissionException(
                    "Existe más de una serie activa en document_series para el doc_type GUIDE_REMISSION."
            );
        }

        DocumentSeriesRow row = rows.get(0);
        if (!hasText(row.series())) {
            throw new InvalidGuideRemissionException(
                    "La serie configurada en document_series para GUIDE_REMISSION no es válida."
            );
        }
        if (row.nextNumber() <= 0) {
            throw new InvalidGuideRemissionException(
                    "El next_number configurado en document_series para GUIDE_REMISSION debe ser mayor a cero."
            );
        }

        jdbcClient.sql("""
                UPDATE document_series
                   SET next_number = next_number + 1
                 WHERE id = ?
                """)
                .param(row.id())
                .update();

        return GuideRemissionGeneratedSeries.builder()
                .serie(row.series().trim())
                .numero(String.valueOf(row.nextNumber()))
                .build();
    }

    @Override
    public GuideRemissionPageResult searchPage(String companyRuc, GuideRemissionPageCriteria criteria) {
        List<Object> params = new ArrayList<>();
        String whereClause = buildSearchWhereClause(companyRuc, criteria, params);

        Long total = jdbcClient.sql("SELECT COUNT(*) FROM guide_remissions gr " + whereClause)
                .params(params)
                .query(Long.class)
                .single();

        List<Object> dataParams = new ArrayList<>(params);
        dataParams.add(criteria.getSize());
        dataParams.add(criteria.getPage() * criteria.getSize());

        List<GuideRemissionPageItem> items = jdbcClient.sql("""
                SELECT gr.id,
                       gr.serie,
                       gr.numero,
                       gr.issue_date,
                       gr.issue_time,
                       gr.transfer_date,
                       gr.status,
                       gr.transfer_mode_code,
                       gr.recipient_document_number,
                       gr.recipient_name,
                       gr.transporter_document_number,
                       gr.transporter_name,
                       gr.driver_dni,
                       gr.driver_full_name,
                       gr.driver_license,
                       gr.vehicle_plate,
                       gr.total_weight,
                       gr.number_of_packages,
                       gr.ticket,
                       gr.ticket_response_code,
                       gr.related_document_type_code,
                       gr.related_document_serie,
                       gr.related_document_numero,
                       gr.submitted_at,
                       gr.created_at,
                       CASE
                           WHEN COALESCE(rd.related_documents_count, 0) > 0 THEN rd.related_documents_count
                           WHEN gr.related_document_type_code IS NOT NULL
                            AND gr.related_document_serie IS NOT NULL
                            AND gr.related_document_numero IS NOT NULL THEN 1
                           ELSE 0
                       END AS related_documents_count,
                       COALESCE(gi.items_count, 0) AS items_count
                  FROM guide_remissions gr
                  LEFT JOIN LATERAL (
                      SELECT COUNT(*) AS related_documents_count
                        FROM guide_remission_related_documents grd
                       WHERE grd.guide_remission_id = gr.id
                  ) rd ON TRUE
                  LEFT JOIN LATERAL (
                      SELECT COUNT(*) AS items_count
                        FROM guide_remission_items gri
                       WHERE gri.guide_remission_id = gr.id
                  ) gi ON TRUE
                """ + whereClause + """
                 ORDER BY gr.created_at DESC, gr.id DESC
                 LIMIT ? OFFSET ?
                """)
                .params(dataParams)
                .query((rs, rowNum) -> {
                    String transferModeCode = rs.getString("transfer_mode_code");
                    boolean isPublicTransport = "01".equals(transferModeCode);
                    boolean isPrivateTransport = "02".equals(transferModeCode);

                    return GuideRemissionPageItem.builder()
                            .id(rs.getLong("id"))
                            .serie(rs.getString("serie"))
                            .numero(rs.getString("numero"))
                            .issueDate(rs.getObject("issue_date", LocalDate.class))
                            .issueTime(rs.getObject("issue_time", LocalTime.class))
                            .transferDate(rs.getObject("transfer_date", LocalDate.class))
                            .status(rs.getString("status"))
                            .transferModeCode(transferModeCode)
                            .transferModeLabel(transportModeLabel(transferModeCode))
                            .recipientDocumentNumber(rs.getString("recipient_document_number"))
                            .recipientName(rs.getString("recipient_name"))
                            .transporterDocumentNumber(isPublicTransport ? rs.getString("transporter_document_number") : null)
                            .transporterName(isPublicTransport ? rs.getString("transporter_name") : null)
                            .driverDocumentNumber(isPrivateTransport ? rs.getString("driver_dni") : null)
                            .driverFullName(isPrivateTransport ? rs.getString("driver_full_name") : null)
                            .driverLicense(isPrivateTransport ? rs.getString("driver_license") : null)
                            .vehiclePlate(isPrivateTransport ? rs.getString("vehicle_plate") : null)
                            .totalWeight(rs.getBigDecimal("total_weight"))
                            .numberOfPackages(rs.getString("number_of_packages"))
                            .ticket(rs.getString("ticket"))
                            .ticketResponseCode(rs.getString("ticket_response_code"))
                            .primaryRelatedDocumentTypeCode(rs.getString("related_document_type_code"))
                            .primaryRelatedDocumentSerie(rs.getString("related_document_serie"))
                            .primaryRelatedDocumentNumero(rs.getString("related_document_numero"))
                            .relatedDocumentsCount(Math.toIntExact(rs.getLong("related_documents_count")))
                            .itemsCount(Math.toIntExact(rs.getLong("items_count")))
                            .submittedAt(rs.getObject("submitted_at", OffsetDateTime.class))
                            .createdAt(rs.getObject("created_at", OffsetDateTime.class))
                            .build();
                })
                .list();

        return GuideRemissionPageResult.builder()
                .items(items)
                .totalElements(total != null ? total : 0L)
                .build();
    }

    private Long insertHeader(GuideRemissionCompany company,
                              GuideRemissionSubmission request,
                              GuideRemissionSubmissionResponse response) {
        GuideRemissionData guia = request.getGuia();
        GuideRemissionRelatedDocument primaryDocument = primaryRelatedDocument(request);

        String insertSql = """
                INSERT INTO guide_remissions(
                    company_ruc,
                    serie,
                    numero,
                    issue_date,
                    issue_time,
                    transfer_date,
                    transfer_reason_code,
                    transfer_mode_code,
                    related_document_type_code,
                    related_document_serie,
                    related_document_numero,
                    transporter_document_number,
                    transporter_name,
                    legacy_transport_entity_id,
                    legacy_transport_mtc_number,
                    driver_dni,
                    driver_full_name,
                    driver_license,
                    vehicle_plate,
                    recipient_document_type,
                    recipient_document_number,
                    recipient_name,
                    departure_ubigeo,
                    departure_address,
                    departure_establishment_code,
                    arrival_ubigeo,
                    arrival_address,
                    arrival_establishment_code,
                    total_weight,
                    number_of_packages,
                    notes,
                    ticket,
                    status,
                    submitted_at,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
                """;

        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcClient.sql(insertSql)
                .params(
                        company.getRuc(),
                        guia.getSerie(),
                        guia.getNumero(),
                        parseLocalDate(guia.getFechaEmision()),
                        parseLocalTime(guia.getHoraEmision()),
                        parseLocalDate(guia.getFechaTraslado()),
                        guia.getGuiaMotivoTraslado(),
                        guia.getGuiaModalidadTraslado(),
                        primaryDocument != null ? normalizeRelatedDocumentType(primaryDocument.getDocumentTypeCode()) : null,
                        primaryDocument != null ? primaryDocument.getSerie() : null,
                        primaryDocument != null ? primaryDocument.getNumero() : null,
                        firstNonBlank(guia.getNumeroDocumentoTransporte(), guia.getEntidadIdTransporte()),
                        guia.getEntidadTransporte(),
                        guia.getEntidadIdTransporte(),
                        guia.getNumeroMtcTransporte(),
                        guia.getConductorDni(),
                        buildDriverFullName(guia),
                        guia.getConductorLicencia(),
                        guia.getVehiculoPlaca(),
                        guia.getDestinatarioTipo(),
                        guia.getDestinatarioNumeroDocumento(),
                        guia.getDestinatarioNombresRazon(),
                        guia.getPartidaUbigeo(),
                        guia.getPartidaDireccion(),
                        guia.getPartidaCodigoEstablecimiento(),
                        guia.getLlegadaUbigeo(),
                        guia.getLlegadaDireccion(),
                        guia.getLlegadaCodigoEstablecimiento(),
                        parseBigDecimal(guia.getPesoTotal()),
                        guia.getNumeroBultos(),
                        guia.getNotas(),
                        response != null ? response.getNumTicket() : null,
                        GuideRemissionStatus.SUBMITTED.name(),
                        parseOffsetDateTime(response != null ? response.getFecRecepcion() : null)
                )
                .update(keyHolder, "id");

        return Optional.ofNullable(keyHolder.getKey())
                .map(Number::longValue)
                .orElseThrow();
    }

    private void updateHeader(Long id,
                              GuideRemissionCompany company,
                              GuideRemissionSubmission request,
                              GuideRemissionSubmissionResponse response) {
        GuideRemissionData guia = request.getGuia();
        GuideRemissionRelatedDocument primaryDocument = primaryRelatedDocument(request);

        String updateSql = """
                UPDATE guide_remissions
                   SET company_ruc = ?,
                       issue_date = ?,
                       issue_time = ?,
                       transfer_date = ?,
                       transfer_reason_code = ?,
                       transfer_mode_code = ?,
                       related_document_type_code = ?,
                       related_document_serie = ?,
                       related_document_numero = ?,
                       transporter_document_number = ?,
                       transporter_name = ?,
                       legacy_transport_entity_id = ?,
                       legacy_transport_mtc_number = ?,
                       driver_dni = ?,
                       driver_full_name = ?,
                       driver_license = ?,
                       vehicle_plate = ?,
                       recipient_document_type = ?,
                       recipient_document_number = ?,
                       recipient_name = ?,
                       departure_ubigeo = ?,
                       departure_address = ?,
                       departure_establishment_code = ?,
                       arrival_ubigeo = ?,
                       arrival_address = ?,
                       arrival_establishment_code = ?,
                       total_weight = ?,
                       number_of_packages = ?,
                       notes = ?,
                       ticket = ?,
                       status = ?,
                       submitted_at = ?,
                       updated_at = NOW()
                 WHERE id = ?
                """;

        jdbcClient.sql(updateSql)
                .params(
                        company.getRuc(),
                        parseLocalDate(guia.getFechaEmision()),
                        parseLocalTime(guia.getHoraEmision()),
                        parseLocalDate(guia.getFechaTraslado()),
                        guia.getGuiaMotivoTraslado(),
                        guia.getGuiaModalidadTraslado(),
                        primaryDocument != null ? normalizeRelatedDocumentType(primaryDocument.getDocumentTypeCode()) : null,
                        primaryDocument != null ? primaryDocument.getSerie() : null,
                        primaryDocument != null ? primaryDocument.getNumero() : null,
                        firstNonBlank(guia.getNumeroDocumentoTransporte(), guia.getEntidadIdTransporte()),
                        guia.getEntidadTransporte(),
                        guia.getEntidadIdTransporte(),
                        guia.getNumeroMtcTransporte(),
                        guia.getConductorDni(),
                        buildDriverFullName(guia),
                        guia.getConductorLicencia(),
                        guia.getVehiculoPlaca(),
                        guia.getDestinatarioTipo(),
                        guia.getDestinatarioNumeroDocumento(),
                        guia.getDestinatarioNombresRazon(),
                        guia.getPartidaUbigeo(),
                        guia.getPartidaDireccion(),
                        guia.getPartidaCodigoEstablecimiento(),
                        guia.getLlegadaUbigeo(),
                        guia.getLlegadaDireccion(),
                        guia.getLlegadaCodigoEstablecimiento(),
                        parseBigDecimal(guia.getPesoTotal()),
                        guia.getNumeroBultos(),
                        guia.getNotas(),
                        response != null ? response.getNumTicket() : null,
                        GuideRemissionStatus.SUBMITTED.name(),
                        parseOffsetDateTime(response != null ? response.getFecRecepcion() : null),
                        id
                )
                .update();
    }

    private void insertRelatedDocuments(Long guideRemissionId, List<GuideRemissionRelatedDocument> relatedDocuments) {
        if (relatedDocuments == null || relatedDocuments.isEmpty()) {
            return;
        }

        String insertSql = """
                INSERT INTO guide_remission_related_documents(
                    guide_remission_id,
                    line_no,
                    document_type_code,
                    document_serie,
                    document_numero,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, NOW(), NOW())
                """;

        int lineNo = 1;
        for (GuideRemissionRelatedDocument document : relatedDocuments) {
            jdbcClient.sql(insertSql)
                    .params(
                            guideRemissionId,
                            lineNo++,
                            normalizeRelatedDocumentType(document.getDocumentTypeCode()),
                            document.getSerie(),
                            document.getNumero()
                    )
                    .update();
        }
    }

    private void insertItems(Long guideRemissionId, List<GuideRemissionItem> items) {
        if (items == null || items.isEmpty()) {
            return;
        }

        String insertItemSql = """
                INSERT INTO guide_remission_items(
                    guide_remission_id,
                    line_no,
                    quantity,
                    description,
                    item_code,
                    unit_code
                ) VALUES (?, ?, ?, ?, ?, ?)
                """;

        String insertAllocationSql = """
                INSERT INTO guide_remission_item_allocations(
                    guide_remission_id,
                    guide_item_line_no,
                    allocation_line_no,
                    related_document_type_code,
                    related_document_serie,
                    related_document_numero,
                    related_document_line_no,
                    source_item_code,
                    source_item_description,
                    quantity,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
                """;

        int lineNo = 1;
        for (GuideRemissionItem item : items) {
            int currentLineNo = lineNo++;

            jdbcClient.sql(insertItemSql)
                    .params(
                            guideRemissionId,
                            currentLineNo,
                            parseBigDecimal(item.getCantidad()),
                            item.getDescripcion(),
                            item.getCodigo(),
                            item.getCodigoUnidad()
                    )
                    .update();

            if (item.getSourceLines() == null || item.getSourceLines().isEmpty()) {
                continue;
            }

            int allocationLineNo = 1;
            for (GuideRemissionItemSourceLine sourceLine : item.getSourceLines()) {
                jdbcClient.sql(insertAllocationSql)
                        .params(
                                guideRemissionId,
                                currentLineNo,
                                allocationLineNo++,
                                normalizeRelatedDocumentType(sourceLine.getRelatedDocumentTypeCode()),
                                sourceLine.getRelatedDocumentSerie(),
                                sourceLine.getRelatedDocumentNumero(),
                                sourceLine.getRelatedDocumentLineNo(),
                                sourceLine.getSourceItemCode(),
                                sourceLine.getSourceItemDescription(),
                                parseBigDecimal(sourceLine.getCantidad())
                        )
                        .update();
            }
        }
    }

    private void deleteItemAllocations(Long guideRemissionId) {
        jdbcClient.sql("DELETE FROM guide_remission_item_allocations WHERE guide_remission_id = ?")
                .param(guideRemissionId)
                .update();
    }

    private void deleteItems(Long guideRemissionId) {
        jdbcClient.sql("DELETE FROM guide_remission_items WHERE guide_remission_id = ?")
                .param(guideRemissionId)
                .update();
    }

    private void deleteRelatedDocuments(Long guideRemissionId) {
        jdbcClient.sql("DELETE FROM guide_remission_related_documents WHERE guide_remission_id = ?")
                .param(guideRemissionId)
                .update();
    }

    private Optional<Long> findId(String companyRuc, String serie, String numero) {
        return jdbcClient.sql("""
                SELECT id
                  FROM guide_remissions
                 WHERE company_ruc = ?
                   AND serie = ?
                   AND numero = ?
                """)
                .params(companyRuc, serie, numero)
                .query(Long.class)
                .optional();
    }

    private List<GuideRemissionRelatedDocument> loadRelatedDocuments(GuideRemissionDocument document) {
        List<GuideRemissionRelatedDocument> relatedDocuments = jdbcClient.sql("""
                SELECT line_no,
                       document_type_code,
                       document_serie,
                       document_numero
                  FROM guide_remission_related_documents
                 WHERE guide_remission_id = ?
                 ORDER BY line_no
                """)
                .param(document.getId())
                .query((rs, rowNum) -> GuideRemissionRelatedDocument.builder()
                        .documentTypeCode(rs.getString("document_type_code"))
                        .serie(rs.getString("document_serie"))
                        .numero(rs.getString("document_numero"))
                        .build())
                .list();

        if (!relatedDocuments.isEmpty()) {
            return relatedDocuments;
        }

        if (hasText(document.getRelatedDocumentTypeCode())
                && hasText(document.getRelatedDocumentSerie())
                && hasText(document.getRelatedDocumentNumero())) {
            return List.of(GuideRemissionRelatedDocument.builder()
                    .documentTypeCode(document.getRelatedDocumentTypeCode())
                    .serie(document.getRelatedDocumentSerie())
                    .numero(document.getRelatedDocumentNumero())
                    .build());
        }

        return new ArrayList<>();
    }

    private List<GuideRemissionDocumentItem> loadItems(Long guideRemissionId) {
        List<GuideRemissionDocumentItem> items = jdbcClient.sql("""
                SELECT line_no, quantity, description, item_code, unit_code
                  FROM guide_remission_items
                 WHERE guide_remission_id = ?
                 ORDER BY line_no
                """)
                .param(guideRemissionId)
                .query((rs, rowNum) -> GuideRemissionDocumentItem.builder()
                        .lineNo(rs.getObject("line_no", Integer.class))
                        .quantity(rs.getBigDecimal("quantity"))
                        .description(rs.getString("description"))
                        .itemCode(rs.getString("item_code"))
                        .unitCode(rs.getString("unit_code"))
                        .sourceAllocations(new ArrayList<>())
                        .build())
                .list();

        Map<Integer, List<GuideRemissionDocumentItemAllocation>> allocationsByItemLine = new LinkedHashMap<>();
        List<AllocationRow> allocationRows = jdbcClient.sql("""
                SELECT guide_item_line_no,
                       allocation_line_no,
                       related_document_type_code,
                       related_document_serie,
                       related_document_numero,
                       related_document_line_no,
                       source_item_code,
                       source_item_description,
                       quantity
                  FROM guide_remission_item_allocations
                 WHERE guide_remission_id = ?
                 ORDER BY guide_item_line_no, allocation_line_no
                """)
                .param(guideRemissionId)
                .query((rs, rowNum) -> new AllocationRow(
                        rs.getObject("guide_item_line_no", Integer.class),
                        GuideRemissionDocumentItemAllocation.builder()
                                .allocationLineNo(rs.getObject("allocation_line_no", Integer.class))
                                .relatedDocumentTypeCode(rs.getString("related_document_type_code"))
                                .relatedDocumentSerie(rs.getString("related_document_serie"))
                                .relatedDocumentNumero(rs.getString("related_document_numero"))
                                .relatedDocumentLineNo(rs.getObject("related_document_line_no", Integer.class))
                                .sourceItemCode(rs.getString("source_item_code"))
                                .sourceItemDescription(rs.getString("source_item_description"))
                                .quantity(rs.getBigDecimal("quantity"))
                                .build()
                ))
                .list();

        for (AllocationRow row : allocationRows) {
            allocationsByItemLine.computeIfAbsent(row.guideItemLineNo(), key -> new ArrayList<>()).add(row.allocation());
        }

        for (GuideRemissionDocumentItem item : items) {
            item.setSourceAllocations(allocationsByItemLine.getOrDefault(item.getLineNo(), new ArrayList<>()));
        }

        return items;
    }

    private String buildSearchWhereClause(String companyRuc, GuideRemissionPageCriteria criteria, List<Object> params) {
        StringBuilder sql = new StringBuilder(" WHERE gr.company_ruc = ?");
        params.add(companyRuc);

        if (hasText(criteria.getQuery())) {
            String like = like(criteria.getQuery());
            sql.append("""
                     AND (
                            UPPER(gr.serie) LIKE ?
                         OR UPPER(gr.numero) LIKE ?
                         OR UPPER(COALESCE(gr.recipient_name, '')) LIKE ?
                         OR UPPER(COALESCE(gr.recipient_document_number, '')) LIKE ?
                         OR UPPER(COALESCE(gr.ticket, '')) LIKE ?
                         OR UPPER(COALESCE(gr.transporter_name, '')) LIKE ?
                         OR UPPER(COALESCE(gr.related_document_type_code, '') || ' ' || COALESCE(gr.related_document_serie, '') || '-' || COALESCE(gr.related_document_numero, '')) LIKE ?
                         OR EXISTS (
                                SELECT 1
                                  FROM guide_remission_related_documents grd
                                 WHERE grd.guide_remission_id = gr.id
                                   AND UPPER(COALESCE(grd.document_type_code, '') || ' ' || COALESCE(grd.document_serie, '') || '-' || COALESCE(grd.document_numero, '')) LIKE ?
                         )
                     )
                    """);
            for (int i = 0; i < 8; i++) {
                params.add(like);
            }
        }

        if (hasText(criteria.getStatus())) {
            sql.append(" AND UPPER(gr.status) = ?");
            params.add(criteria.getStatus().trim().toUpperCase());
        }
        if (hasText(criteria.getSerie())) {
            sql.append(" AND UPPER(gr.serie) LIKE ?");
            params.add(like(criteria.getSerie()));
        }
        if (hasText(criteria.getNumero())) {
            sql.append(" AND UPPER(gr.numero) LIKE ?");
            params.add(like(criteria.getNumero()));
        }
        if (hasText(criteria.getRecipientDocumentNumber())) {
            sql.append(" AND UPPER(COALESCE(gr.recipient_document_number, '')) LIKE ?");
            params.add(like(criteria.getRecipientDocumentNumber()));
        }
        if (hasText(criteria.getRelatedDocument())) {
            sql.append("""
                     AND (
                            UPPER(COALESCE(gr.related_document_type_code, '') || ' ' || COALESCE(gr.related_document_serie, '') || '-' || COALESCE(gr.related_document_numero, '')) LIKE ?
                         OR EXISTS (
                                SELECT 1
                                  FROM guide_remission_related_documents grd
                                 WHERE grd.guide_remission_id = gr.id
                                   AND UPPER(COALESCE(grd.document_type_code, '') || ' ' || COALESCE(grd.document_serie, '') || '-' || COALESCE(grd.document_numero, '')) LIKE ?
                         )
                     )
                    """);
            String relatedDocumentLike = like(criteria.getRelatedDocument());
            params.add(relatedDocumentLike);
            params.add(relatedDocumentLike);
        }
        if (criteria.getIssueDateFrom() != null) {
            sql.append(" AND gr.issue_date >= ?");
            params.add(criteria.getIssueDateFrom());
        }
        if (criteria.getIssueDateTo() != null) {
            sql.append(" AND gr.issue_date <= ?");
            params.add(criteria.getIssueDateTo());
        }
        if (criteria.getTransferDateFrom() != null) {
            sql.append(" AND gr.transfer_date >= ?");
            params.add(criteria.getTransferDateFrom());
        }
        if (criteria.getTransferDateTo() != null) {
            sql.append(" AND gr.transfer_date <= ?");
            params.add(criteria.getTransferDateTo());
        }

        return sql.toString();
    }

    private String like(String value) {
        return "%" + value.trim().toUpperCase() + "%";
    }

    private GuideRemissionRelatedDocument primaryRelatedDocument(GuideRemissionSubmission request) {
        if (request.getRelatedDocuments() != null && !request.getRelatedDocuments().isEmpty()) {
            return request.getRelatedDocuments().get(0);
        }
        if (hasText(request.getRelatedDocumentTypeCode())
                && hasText(request.getRelatedDocumentSerie())
                && hasText(request.getRelatedDocumentNumero())) {
            return GuideRemissionRelatedDocument.builder()
                    .documentTypeCode(request.getRelatedDocumentTypeCode())
                    .serie(request.getRelatedDocumentSerie())
                    .numero(request.getRelatedDocumentNumero())
                    .build();
        }
        return null;
    }

    private void enrichLocationNames(GuideRemissionDocument document) {
        if (document == null) {
            return;
        }

        UbigeoLocation departure = resolveUbigeoLocation(document.getDepartureUbigeo());
        document.setDepartureDepartment(departure.department());
        document.setDepartureProvince(departure.province());
        document.setDepartureDistrict(departure.district());

        UbigeoLocation arrival = resolveUbigeoLocation(document.getArrivalUbigeo());
        document.setArrivalDepartment(arrival.department());
        document.setArrivalProvince(arrival.province());
        document.setArrivalDistrict(arrival.district());
    }

    private UbigeoLocation resolveUbigeoLocation(String ubigeo) {
        if (!hasText(ubigeo)) {
            return UbigeoLocation.empty();
        }

        String code = ubigeo.trim();
        if (!code.matches("\\d{6}")) {
            return UbigeoLocation.empty();
        }

        UbigeoLocation flatCatalogLocation = resolveFromFlatUbigeoCatalog(code);
        if (flatCatalogLocation.hasFullData()) {
            return flatCatalogLocation;
        }

        UbigeoLocation structuredCatalogLocation = resolveFromStructuredUbigeoCatalog(code);
        if (structuredCatalogLocation.hasFullData()) {
            return structuredCatalogLocation;
        }

        if (flatCatalogLocation.hasData()) {
            return flatCatalogLocation.mergeWith(structuredCatalogLocation);
        }

        if (structuredCatalogLocation.hasData()) {
            return structuredCatalogLocation;
        }

        return UbigeoLocation.empty();
    }

    private UbigeoLocation resolveFromFlatUbigeoCatalog(String code) {
        List<String> tableNames = mergeDistinct(List.of(
                "ubigeo",
                "ubigeos",
                "ubigeo_peru",
                "peru_ubigeo",
                "peru_ubigeos",
                "catalog_ubigeo",
                "catalog_ubigeos",
                "sunat_ubigeo",
                "sunat_ubigeos"
        ), findTablesByKeywords(List.of("ubigeo")));

        List<String> codeColumns = List.of("ubigeo", "codigo", "codigo_ubigeo", "code", "district_code", "distrito_code");
        List<String> departmentColumns = List.of("departamento", "department", "department_name", "nombre_departamento");
        List<String> provinceColumns = List.of("provincia", "province", "province_name", "nombre_provincia");
        List<String> districtColumns = List.of("distrito", "district", "district_name", "nombre_distrito");

        for (String tableName : tableNames) {
            String codeColumn = firstExistingColumn(tableName, codeColumns);
            String departmentColumn = firstExistingColumn(tableName, departmentColumns);
            String provinceColumn = firstExistingColumn(tableName, provinceColumns);
            String districtColumn = firstExistingColumn(tableName, districtColumns);

            if (!hasText(codeColumn) || !hasText(departmentColumn) || !hasText(provinceColumn) || !hasText(districtColumn)) {
                continue;
            }

            UbigeoLocation location = querySingleLocation("""
                    SELECT %s AS department,
                           %s AS province,
                           %s AS district
                      FROM %s
                     WHERE CAST(%s AS TEXT) = ?
                    """.formatted(
                    quoteIdentifier(departmentColumn),
                    quoteIdentifier(provinceColumn),
                    quoteIdentifier(districtColumn),
                    quoteIdentifier(tableName),
                    quoteIdentifier(codeColumn)
            ), List.of(code));

            if (location.hasData()) {
                return location;
            }
        }

        return UbigeoLocation.empty();
    }

    private UbigeoLocation resolveFromStructuredUbigeoCatalog(String code) {
        String departmentCode = code.substring(0, 2);
        String provinceFullCode = code.substring(0, 4);
        String provinceShortCode = code.substring(2, 4);
        String districtFullCode = code;
        String districtShortCode = code.substring(4, 6);

        String department = lookupCatalogName(
                mergeDistinct(List.of("departments", "department", "departamentos", "departamento", "catalog_departments", "catalog_departamentos", "sunat_departments", "sunat_departamentos"),
                        findTablesByKeywords(List.of("department", "departamento"))),
                List.of(departmentCode),
                null,
                null
        );

        String province = lookupCatalogName(
                mergeDistinct(List.of("provinces", "province", "provincias", "provincia", "catalog_provinces", "catalog_provincias", "sunat_provinces", "sunat_provincias"),
                        findTablesByKeywords(List.of("province", "provincia"))),
                List.of(provinceFullCode, provinceShortCode),
                departmentCode,
                null
        );

        String district = lookupCatalogName(
                mergeDistinct(List.of("districts", "district", "distritos", "distrito", "catalog_districts", "catalog_distritos", "sunat_districts", "sunat_distritos"),
                        findTablesByKeywords(List.of("district", "distrito"))),
                List.of(districtFullCode, districtShortCode),
                departmentCode,
                provinceFullCode
        );

        if (!hasText(district)) {
            district = lookupCatalogName(
                    mergeDistinct(List.of("districts", "district", "distritos", "distrito", "catalog_districts", "catalog_distritos", "sunat_districts", "sunat_distritos"),
                            findTablesByKeywords(List.of("district", "distrito"))),
                    List.of(districtFullCode, districtShortCode),
                    departmentCode,
                    provinceShortCode
            );
        }

        return new UbigeoLocation(department, province, district);
    }

    private String lookupCatalogName(List<String> tableNames,
                                     List<String> codes,
                                     String departmentCode,
                                     String provinceCode) {
        List<String> codeColumns = List.of("code", "codigo", "ubigeo", "id", "department_code", "province_code", "district_code", "codigo_departamento", "codigo_provincia", "codigo_distrito");
        List<String> nameColumns = List.of("name", "nombre", "description", "descripcion", "department", "departamento", "province", "provincia", "district", "distrito");

        for (String tableName : tableNames) {
            if (!tableExists(tableName)) {
                continue;
            }

            String nameColumn = firstExistingColumn(tableName, nameColumns);
            if (!hasText(nameColumn)) {
                continue;
            }

            for (String codeColumn : existingColumns(tableName, codeColumns)) {
                for (String code : codes) {
                    String name = querySingleName(tableName, nameColumn, codeColumn, code, departmentCode, provinceCode, true);
                    if (hasText(name)) {
                        return name;
                    }

                    name = querySingleName(tableName, nameColumn, codeColumn, code, departmentCode, provinceCode, false);
                    if (hasText(name)) {
                        return name;
                    }
                }
            }
        }

        return null;
    }

    private String querySingleName(String tableName,
                                   String nameColumn,
                                   String codeColumn,
                                   String code,
                                   String departmentCode,
                                   String provinceCode,
                                   boolean useParentFilters) {
        List<Object> params = new ArrayList<>();
        params.add(code);

        StringBuilder sql = new StringBuilder("SELECT ")
                .append(quoteIdentifier(nameColumn))
                .append(" AS name FROM ")
                .append(quoteIdentifier(tableName))
                .append(" WHERE CAST(")
                .append(quoteIdentifier(codeColumn))
                .append(" AS TEXT) = ?");

        if (useParentFilters && hasText(departmentCode)) {
            String depColumn = firstExistingColumn(tableName, List.of("department_code", "codigo_departamento", "departamento_code", "dep_code"));
            if (hasText(depColumn)) {
                sql.append(" AND CAST(").append(quoteIdentifier(depColumn)).append(" AS TEXT) = ?");
                params.add(departmentCode);
            }
        }

        if (useParentFilters && hasText(provinceCode)) {
            String provColumn = firstExistingColumn(tableName, List.of("province_code", "codigo_provincia", "provincia_code", "prov_code"));
            if (hasText(provColumn)) {
                sql.append(" AND CAST(").append(quoteIdentifier(provColumn)).append(" AS TEXT) = ?");
                params.add(provinceCode);
            }
        }

        sql.append(" ORDER BY ").append(quoteIdentifier(nameColumn)).append(" LIMIT 1");

        List<String> names = jdbcClient.sql(sql.toString())
                .params(params)
                .query((rs, rowNum) -> rs.getString("name"))
                .list();

        return names.isEmpty() ? null : names.get(0);
    }

    private UbigeoLocation querySingleLocation(String sql, List<?> params) {
        List<UbigeoLocation> locations = jdbcClient.sql(sql)
                .params(params)
                .query((rs, rowNum) -> new UbigeoLocation(
                        rs.getString("department"),
                        rs.getString("province"),
                        rs.getString("district")
                ))
                .list();

        return locations.isEmpty() ? UbigeoLocation.empty() : locations.get(0);
    }

    private List<String> findTablesByKeywords(List<String> keywords) {
        if (keywords == null || keywords.isEmpty()) {
            return List.of();
        }

        List<String> params = new ArrayList<>();
        StringBuilder where = new StringBuilder();

        for (String keyword : keywords) {
            if (!hasText(keyword)) {
                continue;
            }
            if (!where.isEmpty()) {
                where.append(" OR ");
            }
            where.append("LOWER(table_name) LIKE ?");
            params.add("%" + keyword.toLowerCase() + "%");
        }

        if (params.isEmpty()) {
            return List.of();
        }

        return jdbcClient.sql("""
                SELECT table_name
                  FROM information_schema.tables
                 WHERE table_schema = ANY (current_schemas(false))
                   AND table_type = 'BASE TABLE'
                   AND (%s)
                 ORDER BY table_name
                """.formatted(where))
                .params(params)
                .query((rs, rowNum) -> rs.getString("table_name"))
                .list();
    }

    private List<String> mergeDistinct(List<String> primary, List<String> secondary) {
        List<String> merged = new ArrayList<>();
        addDistinct(merged, primary);
        addDistinct(merged, secondary);
        return merged;
    }

    private void addDistinct(List<String> target, List<String> values) {
        if (values == null) {
            return;
        }
        for (String value : values) {
            if (hasText(value) && !target.contains(value)) {
                target.add(value);
            }
        }
    }

    private List<String> existingColumns(String tableName, List<String> candidates) {
        List<String> columns = new ArrayList<>();
        for (String candidate : candidates) {
            if (hasColumn(tableName, candidate) && !columns.contains(candidate)) {
                columns.add(candidate);
            }
        }
        return columns;
    }

    private String firstExistingColumn(String tableName, List<String> candidates) {
        for (String candidate : candidates) {
            if (hasColumn(tableName, candidate)) {
                return candidate;
            }
        }
        return null;
    }

    private boolean tableExists(String tableName) {
        if (!hasText(tableName)) {
            return false;
        }

        Boolean exists = jdbcClient.sql("""
                SELECT EXISTS (
                    SELECT 1
                      FROM information_schema.tables
                     WHERE table_schema = ANY (current_schemas(false))
                       AND table_type = 'BASE TABLE'
                       AND table_name = ?
                )
                """)
                .params(tableName)
                .query(Boolean.class)
                .single();

        return Boolean.TRUE.equals(exists);
    }

    private boolean hasColumns(String tableName, String... columnNames) {
        for (String columnName : columnNames) {
            if (!hasColumn(tableName, columnName)) {
                return false;
            }
        }
        return true;
    }

    private boolean hasColumn(String tableName, String columnName) {
        if (!hasText(tableName) || !hasText(columnName)) {
            return false;
        }

        Boolean exists = jdbcClient.sql("""
                SELECT EXISTS (
                    SELECT 1
                      FROM information_schema.columns
                     WHERE table_schema = ANY (current_schemas(false))
                       AND table_name = ?
                       AND column_name = ?
                )
                """)
                .params(tableName, columnName)
                .query(Boolean.class)
                .single();

        return Boolean.TRUE.equals(exists);
    }

    private String quoteIdentifier(String identifier) {
        if (!hasText(identifier)) {
            throw new IllegalArgumentException("Identificador SQL vacío.");
        }
        return "\"" + identifier.replace("\"", "\"\"") + "\"";
    }

    private GuideRemissionStatus resolveStatus(GuideRemissionTicketStatusResponse response) {
        String responseCode = firstNonBlank(response.getCdrResponseCode(), response.getTicketRpta());

        if ("0".equals(responseCode)) {
            return GuideRemissionStatus.ACCEPTED;
        }
        if ("98".equals(responseCode)) {
            return GuideRemissionStatus.PROCESSING;
        }
        if ("99".equals(responseCode)) {
            return GuideRemissionStatus.REJECTED;
        }
        return GuideRemissionStatus.TICKET_CHECKED;
    }

    private LocalDate parseLocalDate(String value) {
        return value == null || value.isBlank() ? null : LocalDate.parse(value);
    }

    private LocalTime parseLocalTime(String value) {
        return value == null || value.isBlank() ? null : LocalTime.parse(value);
    }

    private OffsetDateTime parseOffsetDateTime(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }

        String raw = value.trim();

        // Por si alguna respuesta llega con espacio en vez de "T"
        raw = raw.replace(" ", "T");

        // Caso 1: viene con offset: 2026-04-28T00:26:53-05:00 o 2026-04-28T00:26:53Z
        try {
            return OffsetDateTime.parse(raw);
        } catch (DateTimeParseException ignored) {
            // Continúa con otros formatos
        }

        // Caso 2: viene con zona completa
        try {
            return ZonedDateTime.parse(raw).toOffsetDateTime();
        } catch (DateTimeParseException ignored) {
            // Continúa con otros formatos
        }

        // Caso 3: viene sin zona horaria: 2026-04-28T00:26:53
        try {
            return LocalDateTime
                    .parse(raw, DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                    .atZone(GRE_DEFAULT_ZONE)
                    .toOffsetDateTime();
        } catch (DateTimeParseException ignored) {
            // Continúa con fecha simple
        }

        // Caso 4: por si algún día llega solo fecha: 2026-04-28
        try {
            return LocalDate
                    .parse(raw, DateTimeFormatter.ISO_LOCAL_DATE)
                    .atStartOfDay(GRE_DEFAULT_ZONE)
                    .toOffsetDateTime();
        } catch (DateTimeParseException ignored) {
            // Error controlado abajo
        }

        throw new IllegalArgumentException("Fecha/hora GRE inválida: " + value);
    }

    private BigDecimal parseBigDecimal(String value) {
        return value == null || value.isBlank() ? null : new BigDecimal(value);
    }

    private String normalizeRelatedDocumentType(String value) {
        if (value == null || value.trim().isEmpty()) {
            return null;
        }

        String normalized = value.trim().toUpperCase();
        return switch (normalized) {
            case "01", "FACTURA" -> "01";
            case "03", "BOLETA", "BOLETA ELECTRONICA", "BOLETA VENTA ELECTRONICA" -> "03";
            default -> value.trim();
        };
    }


    private String transportModeLabel(String value) {
        if (value == null || value.trim().isEmpty()) {
            return null;
        }

        return switch (value.trim()) {
            case "01" -> "PUBLICO";
            case "02" -> "PRIVADO";
            default -> value.trim();
        };
    }

    private String buildDriverFullName(GuideRemissionData guia) {
        String names = (guia.getConductorNombres() == null ? "" : guia.getConductorNombres().trim());
        String lastNames = (guia.getConductorApellidos() == null ? "" : guia.getConductorApellidos().trim());
        String fullName = (names + " " + lastNames).trim();
        return fullName.isBlank() ? null : fullName;
    }

    private String firstNonBlank(String first, String second) {
        if (first != null && !first.isBlank()) return first;
        if (second != null && !second.isBlank()) return second;
        return null;
    }

    private boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private record StructuredCatalogTables(String departmentsTable, String provincesTable, String districtsTable) {
    }

    private record UbigeoLocation(String department, String province, String district) {
        private static UbigeoLocation empty() {
            return new UbigeoLocation(null, null, null);
        }

        private boolean hasData() {
            return (department != null && !department.isBlank())
                    || (province != null && !province.isBlank())
                    || (district != null && !district.isBlank());
        }

        private boolean hasFullData() {
            return department != null && !department.isBlank()
                    && province != null && !province.isBlank()
                    && district != null && !district.isBlank();
        }

        private UbigeoLocation mergeWith(UbigeoLocation other) {
            if (other == null) {
                return this;
            }
            return new UbigeoLocation(
                    department != null && !department.isBlank() ? department : other.department(),
                    province != null && !province.isBlank() ? province : other.province(),
                    district != null && !district.isBlank() ? district : other.district()
            );
        }
    }

    private record AllocationRow(Integer guideItemLineNo, GuideRemissionDocumentItemAllocation allocation) {
    }

    private record DocumentSeriesRow(Long id, String series, long nextNumber) {
    }
}
