package com.paulfernandosr.possystembackend.guideremission.domain;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class GuideRemissionDocumentItem {
    private Integer lineNo;
    private BigDecimal quantity;
    private String description;
    private String itemCode;
    private String unitCode;

    @Builder.Default
    private List<GuideRemissionDocumentItemAllocation> sourceAllocations = new ArrayList<>();
}
