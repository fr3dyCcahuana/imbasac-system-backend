package com.paulfernandosr.possystembackend.guideremission.domain.port.output;

import com.paulfernandosr.possystembackend.guideremission.domain.GuideRemissionSubmission;
import com.paulfernandosr.possystembackend.guideremission.domain.GuideRemissionSubmissionResponse;
import com.paulfernandosr.possystembackend.guideremission.domain.GuideRemissionTicketQuery;
import com.paulfernandosr.possystembackend.guideremission.domain.GuideRemissionTicketStatusResponse;
import com.paulfernandosr.possystembackend.guideremission.domain.GuideRemissionTokenResponse;

public interface GuideRemissionProvider {
    GuideRemissionTokenResponse requestToken();

    GuideRemissionSubmissionResponse submit(GuideRemissionSubmission request);

    GuideRemissionTicketStatusResponse queryTicket(GuideRemissionTicketQuery request);
}
