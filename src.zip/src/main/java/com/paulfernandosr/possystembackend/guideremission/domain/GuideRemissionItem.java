package com.paulfernandosr.possystembackend.guideremission.domain;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class GuideRemissionItem {
    @NotBlank
    private String cantidad;

    @NotBlank
    private String descripcion;

    @NotBlank
    private String codigo;

    @NotBlank
    private String codigoUnidad;

    @Valid
    private List<GuideRemissionItemSourceLine> sourceLines;
}
