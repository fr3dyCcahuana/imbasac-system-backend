package com.paulfernandosr.possystembackend.countersale.infrastructure.adapter.input.dto;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CounterSaleSunatEmissionInfoResponse {
    private Long saleId;
    private String docType;
    private String series;
    private Long number;
    private String sunatStatus;
    private String sunatCode;
    private String sunatDescription;
    private String hashCode;
    private String xmlPath;
    private String cdrPath;
    private String pdfPath;
    private LocalDateTime emittedAt;

    private Boolean accepted;
    private Boolean rejected;
    private Boolean communicationError;
    private Boolean retryable;
}
